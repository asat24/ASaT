You can go run or go install the CLI tool located in asat_protocol/go
git clone https://github.com/asat_protocol
